import React, { useState, useEffect } from 'react';
import { v4 as uuidv4 } from 'uuid';
import './App.css';

function App() {
  const [notas, setNotas] = useState([]);
  const [notaAtual, setNotaAtual] = useState({
    id: null,
    titulo: '',
    conteudo: '',
    dataCriacao: ''
  });
  const [modoEdicao, setModoEdicao] = useState(false);

  // Carregar notas do localStorage
  useEffect(() => {
    const notasSalvas = localStorage.getItem('notas');
    if (notasSalvas) {
      setNotas(JSON.parse(notasSalvas));
    }
  }, []);

  // Salvar notas no localStorage
  useEffect(() => {
    localStorage.setItem('notas', JSON.stringify(notas));
  }, [notas]);

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setNotaAtual({
      ...notaAtual,
      [name]: value
    });
  };

  const salvarNota = () => {
    if (!notaAtual.titulo.trim() || !notaAtual.conteudo.trim()) {
      alert('Por favor, preencha título e conteúdo!');
      return;
    }

    if (modoEdicao) {
      // Editar nota existente
      setNotas(notas.map(nota => 
        nota.id === notaAtual.id 
          ? { ...notaAtual, dataModificacao: new Date().toLocaleString('pt-BR') }
          : nota
      ));
    } else {
      // Criar nova nota
      const novaNota = {
        id: uuidv4(),
        titulo: notaAtual.titulo,
        conteudo: notaAtual.conteudo,
        dataCriacao: new Date().toLocaleString('pt-BR'),
        dataModificacao: null
      };
      setNotas([novaNota, ...notas]);
    }

    limparFormulario();
  };

  const editarNota = (nota) => {
    setNotaAtual(nota);
    setModoEdicao(true);
  };

  const excluirNota = (id) => {
    if (window.confirm('Tem certeza que deseja excluir esta nota?')) {
      setNotas(notas.filter(nota => nota.id !== id));
      if (modoEdicao && notaAtual.id === id) {
        limparFormulario();
      }
    }
  };

  const limparFormulario = () => {
    setNotaAtual({
      id: null,
      titulo: '',
      conteudo: '',
      dataCriacao: ''
    });
    setModoEdicao(false);
  };

  return (
    <div className="app">
      <header className="app-header">
        <h1>📝 Meu Bloco de Notas</h1>
      </header>

      <div className="container">
        {/* Formulário de Nota */}
        <div className="formulario">
          <h2>{modoEdicao ? 'Editar Nota' : 'Nova Nota'}</h2>
          <input
            type="text"
            name="titulo"
            placeholder="Título da nota..."
            value={notaAtual.titulo}
            onChange={handleInputChange}
            className="input-titulo"
          />
          <textarea
            name="conteudo"
            placeholder="Escreva sua nota aqui..."
            value={notaAtual.conteudo}
            onChange={handleInputChange}
            className="textarea-conteudo"
            rows="6"
          />
          <div className="botoes-formulario">
            <button onClick={salvarNota} className="btn-salvar">
              {modoEdicao ? 'Atualizar' : 'Salvar'} Nota
            </button>
            {modoEdicao && (
              <button onClick={limparFormulario} className="btn-cancelar">
                Cancelar
              </button>
            )}
          </div>
        </div>

        {/* Lista de Notas */}
        <div className="lista-notas">
          <h2>Suas Notas ({notas.length})</h2>
          {notas.length === 0 ? (
            <p className="nenhuma-nota">Nenhuma nota encontrada. Comece criando uma nova!</p>
          ) : (
            <div className="grid-notas">
              {notas.map(nota => (
                <div key={nota.id} className="nota-card">
                  <h3 className="nota-titulo">{nota.titulo}</h3>
                  <p className="nota-conteudo">{nota.conteudo}</p>
                  <div className="nota-metadata">
                    <span>Criada: {nota.dataCriacao}</span>
                    {nota.dataModificacao && (
                      <span>Editada: {nota.dataModificacao}</span>
                    )}
                  </div>
                  <div className="nota-acoes">
                    <button 
                      onClick={() => editarNota(nota)}
                      className="btn-editar"
                    >
                      ✏️ Editar
                    </button>
                    <button 
                      onClick={() => excluirNota(nota.id)}
                      className="btn-excluir"
                    >
                      🗑️ Excluir
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

export default App;